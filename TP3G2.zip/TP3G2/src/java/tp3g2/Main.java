/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tp3g2;

import ISETZG.client.CalcWS_Service;
import javax.xml.ws.WebServiceRef;

/**
 *
 * @author Etudiantzg
 */
public class Main {
        // TODO code application logic here
        @WebServiceRef(wsdlLocation = "META-INF/wsdl/localhost_8080/CalculatriceService/CalcWS.wsdl")
    private static CalcWS_Service service;

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
      System.out.println("la somme de 2011 et 4 est :"+ addition(2011, 4));
    }

    private static int addition(int a, int b) {
        // Note that the injected javax.xml.ws.Service reference as well as port objects are not thread safe.
        // If the calling of port operations may lead to race condition some synchronization is required.
        ISETZG.client.CalcWS port = service.getCalcWSPort();
        return port.addition(a, b);
        
    }
    
    
}
